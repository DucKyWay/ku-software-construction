package com.suphawinee.ku.KuSoftwareConstruction.AfterMid.Interface.first;

public interface NegativeCheckable {

	double getValue();
}
